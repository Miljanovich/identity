# fuksus-identity
esx_identity reskin made by Fuksus team
# Our discord
http://dc.fuksus.com/
